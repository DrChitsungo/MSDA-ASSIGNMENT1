import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_breast_cancer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.metrics import roc_curve, auc
import warnings
warnings.filterwarnings('ignore')

# Set style for better visualizations
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

print("=" * 60)
print("ANDERSON CANCER CENTER - PCA ANALYSIS FOR DONOR FUNDING")
print("=" * 60)

# Step 1: Load the cancer dataset
print("\n1. LOADING BREAST CANCER DATASET")
print("-" * 40)

cancer_data = load_breast_cancer()
X = cancer_data.data
y = cancer_data.target
feature_names = cancer_data.feature_names
target_names = cancer_data.target_names

print(f"Dataset shape: {X.shape}")
print(f"Number of features: {len(feature_names)}")
print(f"Number of samples: {X.shape[0]}")
print(f"Target classes: {target_names}")
print(f"Class distribution:")
unique, counts = np.unique(y, return_counts=True)
for i, (class_name, count) in enumerate(zip(target_names, counts)):
    print(f" - {class_name}: {count} ({count/len(y)*100:.1f}%)")

# Create DataFrame for better handling
df = pd.DataFrame(X, columns=feature_names)
df['target'] = y

print(f"\nFirst few feature names:")
for i, name in enumerate(feature_names[:10]):
    print(f" {i+1}. {name}")
print(" ... and 20 more features")

# Step 2: Data preprocessing and standardization
print("\n\n2. DATA PREPROCESSING")
print("-" * 40)

# Check for missing values
print(f"Missing values: {df.isnull().sum().sum()}")

# Standardize the features (crucial for PCA)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

print("✓ Features standardized (mean=0, std=1)")
print(f"Original feature means range: [{X.mean(axis=0).min():.2f}, {X.mean(axis=0).max():.2f}]")
print(f"Scaled feature means range: [{X_scaled.mean(axis=0).min():.6f}, {X_scaled.mean(axis=0).max():.6f}]")

# Step 3: Apply PCA
print("\n\n3. PRINCIPAL COMPONENT ANALYSIS")
print("-" * 40)

# First, let's see how much variance each component explains
pca_full = PCA()
pca_full.fit(X_scaled)

# Calculate cumulative explained variance
cumulative_variance = np.cumsum(pca_full.explained_variance_ratio_)
print(f"Cumulative explained variance by components: {cumulative_variance}")


print("Explained variance by first 10 components:")
for i in range(10):
        print(f" PC{i+1}: {pca_full.explained_variance_ratio_[i]*100:.2f}% "
            f"(Cumulative: {cumulative_variance[i]*100:.2f}%)")

# Apply PCA with 2 components as requested
pca_2d = PCA(n_components=2)
X_pca = pca_2d.fit_transform(X_scaled)

print(f"\n✓ PCA with 2 components completed")
print(f"Explained variance by 2 components: {pca_2d.explained_variance_ratio_.sum()*100:.2f}%")
print(f" - PC1: {pca_2d.explained_variance_ratio_[0]*100:.2f}%")
print(f" - PC2: {pca_2d.explained_variance_ratio_[1]*100:.2f}%")

# Step 4: Analyze PCA components
print("\n\n4. PCA COMPONENTS ANALYSIS")
print("-" * 40)

# Get the component loadings
components_df = pd.DataFrame(
pca_2d.components_.T,
    columns=['PC1', 'PC2'],
    index=feature_names
        )

print("Top 5 features contributing to PC1:")
pc1_abs = components_df['PC1'].abs().sort_values(ascending=False)
for i, (feature, loading) in enumerate(pc1_abs.head().items()):
    original_loading = components_df.loc[feature, 'PC1']
    print(f" {i+1}. {feature}: {original_loading:.3f}")

print("\nTop 5 features contributing to PC2:")
pc2_abs = components_df['PC2'].abs().sort_values(ascending=False)
for i, (feature, loading) in enumerate(pc2_abs.head().items()):
    original_loading = components_df.loc[feature, 'PC2']
    print(f" {i+1}. {feature}: {original_loading:.3f}")

# Step 5: Visualizations
print("\n\n5. CREATING VISUALIZATIONS")
print("-" * 40)

fig, axes = plt.subplots(2, 2, figsize=(15, 12))
fig.suptitle('Anderson Cancer Center - PCA Analysis Results', fontsize=16, fontweight='bold')

# Plot 1: Explained Variance
axes[0,0].plot(range(1, 11), pca_full.explained_variance_ratio_[:10], 'bo-', linewidth=2, markersize=8)
axes[0,0].set_xlabel('Principal Component')
axes[0,0].set_ylabel('Explained Variance Ratio')
axes[0,0].set_title('Explained Variance by Component')
axes[0,0].grid(True, alpha=0.3)
axes[0,0].set_xticks(range(1, 11))

# Plot 2: Cumulative Explained Variance
axes[0,1].plot(range(1, 11), cumulative_variance[:10], 'ro-', linewidth=2, markersize=8)
axes[0,1].axhline(y=0.8, color='g', linestyle='--', alpha=0.7, label='80% Variance')
axes[0,1].axhline(y=0.95, color='orange', linestyle='--', alpha=0.7, label='95% Variance')
axes[0,1].set_xlabel('Number of Components')
axes[0,1].set_ylabel('Cumulative Explained Variance')
axes[0,1].set_title('Cumulative Explained Variance')
axes[0,1].legend()
axes[0,1].grid(True, alpha=0.3)
axes[0,1].set_xticks(range(1, 11))

# Plot 3: PCA Scatter Plot
scatter = axes[1,0].scatter(X_pca[:, 0], X_pca[:, 1], c=y, cmap='viridis', alpha=0.7, s=50)
axes[1,0].set_xlabel(f'PC1 ({pca_2d.explained_variance_ratio_[0]*100:.1f}% variance)')
axes[1,0].set_ylabel(f'PC2 ({pca_2d.explained_variance_ratio_[1]*100:.1f}% variance)')
axes[1,0].set_title('Cancer Data in 2D PCA Space')
cbar = plt.colorbar(scatter, ax=axes[1,0])
cbar.set_label('Diagnosis (0=Malignant, 1=Benign)')

# Plot 4: Feature Contribution Heatmap
top_features = list(pc1_abs.head(10).index)
heatmap_data = components_df.loc[top_features, ['PC1', 'PC2']]
sns.heatmap(heatmap_data, annot=True, cmap='RdBu_r', center=0,
ax=axes[1,1], cbar_kws={'label': 'Loading'})
axes[1,1].set_title('Top 10 Feature Loadings on PC1 & PC2')
axes[1,1].set_ylabel('Features')

plt.tight_layout()
plt.show()

# Step 6: Bonus - Logistic Regression Implementation
print("\n\n6. BONUS: LOGISTIC REGRESSION WITH PCA COMPONENTS")
print("-" * 50)

# Split the data
X_train, X_test, y_train, y_test = train_test_split(
X_pca, y, test_size=0.2, random_state=42, stratify=y
)

print(f"Training set: {X_train.shape[0]} samples")
print(f"Test set: {X_test.shape[0]} samples")

# Train logistic regression on PCA components
lr_model = LogisticRegression(random_state=42)
lr_model.fit(X_train, y_train)

# Make predictions
y_pared = lr_model.predict(X_test)
y_pared_proba = lr_model.predict_proba(X_test)[:, 1]

# Evaluate model
accuracy = accuracy_score(y_test, y_pared)
print(f"\n✓ Logistic Regression Model Performance:")
print(f"Accuracy: {accuracy*100:.2f}%")

print(f"\nDetailed Classification Report:")
print(classification_report(y_test, y_pared, target_names=target_names))

# Confusion Matrix
print(f"Confusion Matrix:")
cm = confusion_matrix(y_test, y_pared)
print(cm)

# ROC Curve
fpr, tpr, _ = roc_curve(y_test, y_pared_proba)
roc_auc = auc(fpr, tpr)

plt.figure(figsize=(10, 4))

plt.subplot(1, 2, 1)
plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (AUC = {roc_auc:.3f})')
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve - Logistic Regression on PCA')
plt.legend(loc="lower right")
plt.grid(alpha=0.3)

# Confusion Matrix Heatmap
plt.subplot(1, 2, 2)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
xticklabels=target_names, yticklabels=target_names)
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('Actual')

plt.tight_layout()
plt.show()

# Step 7: Business Insights for Donor Funding
print("\n\n7. BUSINESS INSIGHTS FOR DONOR FUNDING")
print("-" * 50)

print("KEY FINDINGS FOR ANDERSON CANCER CENTER:")
print("\n DATASET OVERVIEW:")
print(f" • Total patient records analyzed: {X.shape[0]:,}")
print(f" • Original features: {X.shape[1]} clinical measurements")
print(f" • Diagnosis distribution: {counts[1]} benign, {counts[0]} malignant cases")

print("\n PCA ANALYSIS RESULTS:")
print(f" • 2 principal components explain {pca_2d.explained_variance_ratio_.sum()*100:.1f}% of data variance")
print(f" • PC1 captures {pca_2d.explained_variance_ratio_[0]*100:.1f}% - primary disease patterns")
print(f" • PC2 captures {pca_2d.explained_variance_ratio_[1]*100:.1f}% - secondary characteristics")

print("\n MOST IMPORTANT VARIABLES FOR FUNDING FOCUS:")
print(" Top 5 clinical indicators (PC1):")
for i, (feature, _) in enumerate(pc1_abs.head().items()):
    print(f" {i+1}. {feature}")

print("\n PREDICTIVE MODEL PERFORMANCE:")
print(f" • Classification accuracy: {accuracy*100:.1f}%")
print(f" • AUC score: {roc_auc:.3f}")
print(f" • Model can effectively distinguish malignant vs. benign cases")

print("\n RECOMMENDATIONS FOR DONOR PRESENTATIONS:")
print(" 1. Focus funding on equipment measuring top PC1 features")
print(" 2. Emphasize the {:.1f}% diagnostic accuracy potential".format(accuracy*100))
print(" 3. Highlight dimensionality reduction saves costs while maintaining performance")
print(" 4. Show clear separation between cancer types in 2D visualization")
print(" 5. Demonstrate evidence-based approach to resource allocation")

print("\n" + "="*60)
print("ANALYSIS COMPLETE - READY FOR DONOR PRESENTATION")
print("="*60)
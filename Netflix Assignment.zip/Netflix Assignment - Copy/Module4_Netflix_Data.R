# =========================================================
# Netflix Analysis in R (R >= 4.5)
# - Top 15 Most Watched Genres (Bar Chart)
# - Ratings Distribution (Pie Chart)
# =========================================================

# 1 Install and load required libraries
# Uncomment install.packages lines if the packages are not yet installed
#install.packages("tidyverse")  

library(tidyverse)   # Includes ggplot2, dplyr, tidyr for data manipulation & plotting
library(readr)       # For reading CSV files

# ---------------------------------------------------------
# 2️ Load the Netflix dataset
# Replace the path below with your CSV file path
netflix <- read_csv("C:\\Users\\Hp\\OneDrive\\Desktop\\Netflix Assignment\\Netflix_shows_movies.csv")


# 
# # ---------------------------------------------------------
# # 3️ TOP 15 MOST WATCHED GENRES (Bar Chart)
# # ---------------------------------------------------------
# 
# # Step 3a: Prepare the genres data
# all_genres <- netflix %>%
#   filter(!is.na(listed_in)) %>%             # Remove rows where genres are missing
#   separate_rows(listed_in, sep = ",") %>%  # Split multiple genres into separate rows
#   mutate(listed_in = str_trim(listed_in))  # Remove leading/trailing whitespace
# 
# # Step 3b: Count the number of titles per genre
# top_genres <- all_genres %>%
#   count(listed_in, sort = TRUE) %>%        # Count titles per genre, sorted descending
#   top_n(15, n)                             # Keep top 15 genres only
# 
# # Step 3c: Plot the Top 15 genres bar chart
# ggplot(top_genres, aes(x = reorder(listed_in, n), y = n)) +
#   geom_bar(stat = "identity", fill = "steelblue") +  # Create bars
#   coord_flip() +                                     # Flip axes for horizontal bars
#   labs(title = "Top 15 Most Watched Netflix Genres",
#        x = "Genre",
#        y = "Number of Titles") +
#   theme_minimal(base_size = 14)                      # Clean minimal theme
# 

# ---------------------------------------------------------
#  RATINGS DISTRIBUTION (Pie Chart)
# ---------------------------------------------------------

# Step 4a: Count the number of titles per rating
rating_counts <- netflix %>%
  filter(!is.na(rating)) %>%   # Remove missing ratings
  count(rating)                # Count number of titles per rating

# Step 4b: Plot the Ratings Distribution Pie Chart
ggplot(rating_counts, aes(x = "", y = n, fill = rating)) +
  geom_col(width = 1) +        # Create bar heights for pie
  coord_polar(theta = "y") +   # Transform bar chart into pie chart
  labs(title = "Netflix Content Rating Distribution") +
  theme_void() +               # Remove axes
  theme(legend.title = element_blank())  # Remove legend title for clarity

# =========================================================
# End of R Script
# =========================================================

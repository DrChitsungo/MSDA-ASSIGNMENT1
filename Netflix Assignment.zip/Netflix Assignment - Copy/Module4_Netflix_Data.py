import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import zipfile
import os
import shutil
from collections import Counter
import warnings

# Suppress warnings for cleaner console output
warnings.filterwarnings('ignore')

# Set global plot styles
plt.style.use('default')  # Default matplotlib style
sns.set_palette("husl")  # Set seaborn color palette globally


class NetflixAnalysis:
    def __init__(self, zip_path, new_name="Netflix_shows_movies"):
        """
        Initialize the NetflixAnalysis class.

        Parameters:
        - zip_path: str, path to the zip file containing the dataset.
        - new_name: str, name to save the CSV after unzipping.
        """
        self.zip_path = zip_path
        self.new_name = new_name
        self.df = None  # Placeholder for the DataFrame
        self.output_dir = os.path.dirname(os.path.abspath(zip_path))  # Where figures will be saved

    def unzip_and_rename_dataset(self):
        """Unzip the dataset and rename it to a consistent name."""
        try:
            extract_dir = "C:/Users/Hp/OneDrive/Desktop/Netflix Assignment/Module_4_Assignment_Netflix_Data_B.Chitsungo"  # Temporary extraction folder
            if not os.path.exists(extract_dir):
                os.makedirs(extract_dir)  # Create folder if it doesn't exist

            # Extract the zip file
            with zipfile.ZipFile(self.zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)  # Extract all files
                file_list = zip_ref.namelist()
                print(f"Extracted files: {file_list}")

            # Find CSV files inside the extracted folder
            csv_files = []
            for root, dirs, files in os.walk(extract_dir):
                for file in files:
                    if file.endswith('.csv'):
                        csv_files.append(os.path.join(root, file))

            if not csv_files:
                print("No CSV files found in the archive")
                return None

            # Take the first CSV found and copy it as new_name
            original_file = csv_files[0]
            zip_dir = os.path.dirname(self.zip_path)  # Get directory of the ZIP file
            new_filename = f"{self.new_name}.csv"
            saved_file = os.path.join(zip_dir, new_filename)
            shutil.copy2(original_file, saved_file)
            print(f"Dataset successfully unzipped and renamed to: {new_filename}")
            return saved_file

        except Exception as e:
            print(f"Error processing zip file: {e}")
            return None

    def load_and_clean_data(self, filename):
        """Load the CSV dataset into a DataFrame and handle missing values."""
        try:
            # Load CSV
            self.df = pd.read_csv(filename)
            print("Dataset loaded successfully!")
            print(f"Original shape: {self.df.shape}")

            # Print dataset info
            print("\nDataset Info:")
            print(self.df.info())

            # Analyze missing values
            print("\nMissing Values Analysis:")
            missing_values = self.df.isnull().sum()
            missing_percentage = (missing_values / len(self.df)) * 100
            missing_df = pd.DataFrame({
                'Missing Count': missing_values,
                'Missing Percentage': missing_percentage
            })
            print(missing_df[missing_df['Missing Count'] > 0])

            # Handle missing categorical values
            categorical_cols = self.df.select_dtypes(include=['object']).columns
            for col in categorical_cols:
                if self.df[col].isnull().sum() > 0:
                    if col in ['director', 'cast', 'country']:
                        self.df[col] = self.df[col].fillna('Unknown')  # Fill with 'Unknown'
                    else:
                        # Fill with mode (most frequent value)
                        self.df[col] = self.df[col].fillna(
                            self.df[col].mode()[0] if len(self.df[col].mode()) > 0 else 'Unknown'
                        )

            # Handle missing numerical values
            numerical_cols = self.df.select_dtypes(include=[np.number]).columns
            for col in numerical_cols:
                if self.df[col].isnull().sum() > 0:
                    self.df[col] = self.df[col].fillna(self.df[col].median())  # Fill with median

            # Handle date column
            if 'date_added' in self.df.columns:
                self.df['date_added'] = pd.to_datetime(self.df['date_added'], errors='coerce')
                self.df['date_added'] = self.df['date_added'].fillna(pd.to_datetime('1900-01-01'))

            print(f"Missing values handled. New shape: {self.df.shape}")
            return self.df

        except Exception as e:
            print(f"Error loading dataset: {e}")
            return None

    def explore_data(self):
        """Display summary statistics and basic exploratory analysis."""
        df = self.df
        print("\n" + "=" * 60)
        print("DATA EXPLORATION AND STATISTICAL ANALYSIS")
        print("=" * 60)

        # Basic overview
        print("\n1. BASIC DATASET OVERVIEW:")
        print(f"   • Total records: {len(df):,}")
        print(f"   • Total columns: {len(df.columns)}")
        print(f"   • Memory usage: {df.memory_usage(deep=True).sum() / 1024 ** 2:.2f} MB")

        # Show first few rows
        print("\n2. SAMPLE DATA:")
        print(df.head())

        # Unique values per column
        print("\n3. COLUMN ANALYSIS:")
        for col in df.columns:
            print(f"   • {col}: {df[col].nunique():,} unique values, Type: {df[col].dtype}")

        # Ratings distribution
        if 'rating' in df.columns:
            print("\n4. RATING DISTRIBUTION:")
            rating_counts = df['rating'].value_counts()
            for rating, count in rating_counts.head(10).items():
                print(f"   • {rating}: {count:,} ({(count / len(df)) * 100:.1f}%)")

    def statistical_analysis(self):
        """Detailed statistical analysis for numerical and categorical columns."""
        df = self.df
        print("\n" + "=" * 60)
        print("DETAILED STATISTICAL ANALYSIS")
        print("=" * 60)

        # Numerical columns stats
        numerical_cols = df.select_dtypes(include=[np.number]).columns
        if len(numerical_cols) > 0:
            print("\n1. NUMERICAL VARIABLES STATISTICS:")
            print(df[numerical_cols].describe())

        # Categorical columns analysis
        categorical_cols = df.select_dtypes(include=['object']).columns
        print("\n2. CATEGORICAL VARIABLES ANALYSIS:")
        for col in categorical_cols[:5]:
            print(f"\n   {col.upper()}:")
            value_counts = df[col].value_counts().head(10)
            for value, count in value_counts.items():
                print(f"      • {value}: {count:,} ({(count / len(df)) * 100:.1f}%)")

    def create_visualizations(self):
        """Generate and save only the two relevant visualizations:
        1. Top 15 Most Watched Genres
        2. Ratings Distribution Pie Chart
        """
        df = self.df
        print("\n" + "=" * 60)
        print("CREATING VISUALIZATIONS")
        print("=" * 60)

        # Create a 1-row, 2-column figure
        fig, axes = plt.subplots(1, 2, figsize=(16, 6))
        fig.suptitle('Netflix Content Analysis', fontsize=16, fontweight='bold')

        # --- Top Genres Bar Chart ---
        if 'listed_in' in df.columns:
            all_genres = []
            for genres in df['listed_in'].dropna():
                all_genres.extend([genre.strip() for genre in str(genres).split(',')])
            genre_counts = Counter(all_genres)
            top_genres = dict(genre_counts.most_common(15))  # Top 15 genres
            genres_df = pd.DataFrame(list(top_genres.items()), columns=['Genre', 'Count'])
            sns.barplot(data=genres_df, y='Genre', x='Count', ax=axes[0], palette='viridis')
            axes[0].set_title('Top 15 Most Watched Genres', fontweight='bold')
            axes[0].set_xlabel('Number of Titles')
            axes[0].set_ylabel('Genre')

        # --- Ratings Distribution Pie Chart ---
        if 'rating' in df.columns:
            rating_counts = df['rating'].value_counts()
            colors = sns.color_palette('Set3', len(rating_counts))
            axes[1].pie(rating_counts.values, labels=rating_counts.index, autopct='%1.1f%%',
                        colors=colors, startangle=90)
            axes[1].set_title('Content Rating Distribution', fontweight='bold')

        # Adjust layout to prevent overlap
        plt.tight_layout(rect=[0, 0, 1, 0.95])

        # Save figure
        save_path = os.path.join(self.output_dir, "netflix_top_genres_ratings.png")
        plt.savefig(save_path)
        print(f"Visualizations saved at: {save_path}")

        # Display figure
        plt.show()

    def run_pipeline(self):
        """Run the entire analysis pipeline."""
        print("NETFLIX DATASET ANALYSIS PIPELINE")
        print("=" * 50)

        print("\nStep 1: Unzipping and renaming dataset...")
        csv_filename = self.unzip_and_rename_dataset()
        if csv_filename is None:
            return

        print("\nStep 2: Loading and cleaning data...")
        df = self.load_and_clean_data(csv_filename)
        if df is None:
            return

        print("\nStep 3: Performing data exploration...")
        self.explore_data()

        print("\nStep 4: Conducting statistical analysis...")
        self.statistical_analysis()

        print("\nStep 5: Creating visualizations...")
        self.create_visualizations()

        print("\n" + "=" * 60)
        print("ANALYSIS COMPLETE!")
        print("=" * 60)


if __name__ == "__main__":
    # Path to zip file containing Netflix dataset
    zip_file_path = r"C:/Users/Hp/OneDrive/Desktop/Netflix Assignment/netflix_data.zip.zip"


    # Initialize analysis object and run pipeline
    analysis = NetflixAnalysis(zip_file_path)
    analysis.run_pipeline()

Netflix Dataset Analysis
This project provides a comprehensive analysis pipeline for a Netflix dataset contained within a ZIP archive. It includes data extraction, cleaning, exploratory data analysis, statistical summaries, and visualization of key insights.

Features
* Unzip and rename dataset: Extracts the dataset CSV from a ZIP file and saves it with a consistent filename.
* Data loading and cleaning: Loads the dataset into a pandas DataFrame, handles missing values intelligently for categorical, numerical, and date columns.
* Exploratory data analysis: Prints dataset overview, sample data, unique values per column, and rating distribution.
* Statistical analysis: Provides descriptive statistics for numerical columns and frequency analysis for categorical columns.
* Visualizations:
o Bar chart of the top 15 most watched genres.
o Pie chart showing the distribution of content ratings.
* Modular design: Encapsulated in a
Copy code
NetflixAnalysis
�class for easy reuse and extension.

Requirements
* Python 3.6+
* Packages:
o pandas
o numpy
o matplotlib
o seaborn
Install required packages via pip if needed:
bash
Copy code
pip install pandas numpy matplotlib seaborn

Usage
1. Prepare your dataset ZIP file
Place your Netflix dataset ZIP file on your local machine. Update the
Copy code
zip_file_path
�variable in the script to point to your ZIP file location.
2. Run the script
Execute the script directly:
bash
Copy code
python netflix_analysis.py
The script will:
o Extract the dataset CSV from the ZIP archive.
o Load and clean the data.
o Perform exploratory and statistical analysis with console output.
o Generate and save visualizations (
Copy code
netflix_top_genres_ratings.png
) in the same directory as the ZIP file.
o Display the visualizations.
Code Structure
* Copy code
NetflixAnalysis
�class:
o Copy code
__init__(zip_path, new_name)
: Initialize with path to ZIP file and desired CSV filename.
o Copy code
unzip_and_rename_dataset()
: Extracts and renames the dataset CSV.
o Copy code
load_and_clean_data(filename)
: Loads CSV into DataFrame and handles missing data.
o Copy code
explore_data()
: Prints dataset overview and basic analysis.
o Copy code
statistical_analysis()
: Prints detailed statistics for numerical and categorical columns.
o Copy code
create_visualizations()
: Creates and saves bar and pie charts for genres and ratings.
o Copy code
run_pipeline()
: Runs all steps in sequence.
Notes
* The extraction directory is currently hardcoded to:
Copy code
C:/Users/Hp/OneDrive/Desktop/Netflix Assignment/Module_4_Assignment_Netflix_Data_B.Chitsungo
You may want to modify this path in the
Copy code
unzip_and_rename_dataset
�method to suit your environment.
* The script suppresses warnings for cleaner output.
* Visualizations are saved as
Copy code
netflix_top_genres_ratings.png
�in the ZIP file's directory.
Copy code
if __name__ == "__main__":
    zip_file_path = r"C:/Users/Hp/OneDrive/Desktop/Netflix Assignment/netflix_data.zip.zip"
    analysis = NetflixAnalysis(zip_file_path)
    analysis.run_pipeline()

License
This project is provided as-is for educational and analytical purposes.

